package com.gabriel.ex2.model;

public interface IRenovavel {
    public void renovarAssinatura();
    public void cancelarAssinatura(String dataCancelamento);
}
