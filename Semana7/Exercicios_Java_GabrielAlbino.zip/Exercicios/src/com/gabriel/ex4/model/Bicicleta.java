package com.gabriel.ex4.model;

public class Bicicleta {
    
}
